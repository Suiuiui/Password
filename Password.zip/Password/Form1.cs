﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Password
{
    public partial class frmLogin : Form
    {
        public frmLogin()
        {
            InitializeComponent();
        }

        private void btnsub_Click(object sender, EventArgs e)
        {
            
            string query = "SELECT password FROM [The Password] WHERE username = @Username";
            string conn = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=Z:\\QQ121\\Password.mdb";
            using (OleDbConnection connect = new OleDbConnection(conn))
            {
                connect.Open();

                using (OleDbCommand cmd = new OleDbCommand(query, connect))
                {
                    cmd.Parameters.AddWithValue("@Username", usertxt.Text);
                    string passFromDatabase = (string)cmd.ExecuteScalar();

                    if(passtxt.Text == passFromDatabase)
                    {
                        MessageBox.Show("LOGIN SUCCESSFULLY");

                    }
                    else
                    {
                        MessageBox.Show("INCORRECT PASSWORD OR USERNAME");
                    }
                    frmMenu f1 = new frmMenu();
                    f1.ShowDialog();

                }
            }
        }
    }
}
